﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Projekt_filmy
{
    public class BazaDanych : ICloneable
    {
        List<Klient> klienci;

        public List<Film> Filmy { get; set; } = new List<Film>();
        public List<Klient> Klienci { get => klienci; set => klienci = value; }
        public List<Transakcja> Transakcje { get; set; } = new List<Transakcja>();


        public List<Transakcja> PobierzWszystkieTransakcje()
        {
            // Tutaj zwróć listę transakcji z bazy danych
            // Na przykład:
            return Transakcje;
        }

        public BazaDanych()
        {
            Klienci = new();
       
        }
        // Metoda dodająca film do listy
        public void DodajFilm(Film film)
        {
            Filmy.Add(film);
        }

        // Metoda usuwająca film z listy
        public void UsuńFilm(int filmID)
        {
            Film filmDoUsunięcia = Filmy.FirstOrDefault(f => f.ID == filmID);
            if (filmDoUsunięcia != null)
            {
                Filmy.Remove(filmDoUsunięcia);
            }
            else
            {
                Console.WriteLine($"Film o ID {filmID} nie został znaleziony.");
            }
        }

        // Metoda dodająca klienta do listy
        public void DodajKlienta(Klient klient)
        {
            Klienci.Add(klient);
        }

        // Metoda usuwająca klienta z listy
        public void UsuńKlienta(int klientID)
        {
            Klient klientDoUsunięcia = Klienci.FirstOrDefault(k => k.ID == klientID);
            if (klientDoUsunięcia != null)
            {
                Klienci.Remove(klientDoUsunięcia);
            }
            else
            {
                Console.WriteLine($"Klient o ID {klientID} nie został znaleziony.");
            }
        }

        // Metoda dodająca transakcję do listy
        public void DodajTransakcję(Transakcja transakcja)
        {
            Transakcje.Add(transakcja);
        }

        // Metoda usuwająca transakcję z listy
        public void UsuńTransakcję(int transakcjaID)
        {
            Transakcja transakcjaDoUsunięcia = Transakcje.FirstOrDefault(t => t.IDTransakcji == transakcjaID);
            if (transakcjaDoUsunięcia != null)
            {
                Transakcje.Remove(transakcjaDoUsunięcia);
            }
            else
            {
                Console.WriteLine($"Transakcja o ID {transakcjaID} nie została znaleziona.");
            }
        }

        // Metoda do zapisu bazy danych do pliku XML
        public void ZapiszDoPliku(string nazwaPliku)
        {
            using StreamWriter sw = new(nazwaPliku);
            XmlSerializer xs = new(typeof(BazaDanych));
            xs.Serialize(sw, this);
        }

        // Metoda do odczytu bazy danych z pliku XML
        public static BazaDanych OdczytajZPliku(string nazwaPliku)
        {
            if (File.Exists(nazwaPliku))
            {
                using (FileStream fs = new FileStream(nazwaPliku, FileMode.Open))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(BazaDanych));
                    return (BazaDanych)serializer.Deserialize(fs);
                }
            }
            else
            {
                Console.WriteLine("Plik nie istnieje. Tworzę nową bazę danych.");
                return new BazaDanych();
            }
        }

        public object Clone()
        {
            throw new NotImplementedException();
        }
    }
}
