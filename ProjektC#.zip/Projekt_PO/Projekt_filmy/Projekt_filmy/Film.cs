﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_filmy
{


    public class WrongFilmException : Exception
    {
        public WrongFilmException(string message) : base(message) { }
    }
    public abstract class FilmBase
    {
        public abstract void PobierzInformacje();
    }
    public interface IFilmOperacje
    {
        void Wypożycz();
        void Zwróć();
        bool SprawdźDostępność();
        abstract void PobierzInformacje();
    }

    // Klasa Film
    public class Film : FilmBase, IFilmOperacje, IEquatable<Film>
    {
        public int iD;
        public static int licznikFilm;
        public string tytul;
        public string reżyser;
        public int rokProdukcji;
        public string gatunek;
        public int czasTrwania;
        public double ocena;
        public bool dostepny;

        public int ID { get; set; }
        public string Tytuł { get; set; }
        public string Reżyser { get; set; }
        public int RokProdukcji
        {
            get { return rokProdukcji; }
            set
            {
                if (value < 1900 || value > DateTime.Now.Year)
                {
                    throw new WrongFilmException("Nieprawidłowy rok produkcji filmu");
                }
                rokProdukcji = value;
            }
        }
        public string Gatunek { get; set; }
        public int CzasTrwania { get; set; }
        public double Ocena
        {
            get { return ocena; }
            set
            {
                if (value < 0 || value > 10)
                {
                    throw new WrongFilmException("Nieprawidłowa ocena filmu. Ocena powinna być w zakresie od 0 do 10.");
                }
                ocena = value;
            }
        }
        public bool Dostępny { get; set; } = true;


        static Film()
        {
            licznikFilm = 1;
        }

        public Film()
        {
            ID = licznikFilm;
            licznikFilm++;
        }

        public Film(int iD, string tytuł, string reżyser, int rokProdukcji, string gatunek, int czasTrwania, double ocena, bool dostępny)
            : this()
        {
            Tytuł = tytuł;
            Reżyser = reżyser;
            RokProdukcji = rokProdukcji;
            Gatunek = gatunek;
            CzasTrwania = czasTrwania;
            Ocena = ocena;
            Dostępny = dostępny;
 
        }

        public void Wypożycz()
        {
            if (Dostępny)
            {
                Dostępny = false;
                Console.WriteLine("Film wypożyczony.");
            }
            else
            {
                Console.WriteLine("Film niedostępny do wypożyczenia.");
            }
        }


        public void Zwróć()
        {
            Dostępny = true;
            Console.WriteLine("Film został zwrócony.");
        }

        public bool SprawdźDostępność()
        {
            return Dostępny;
        }

        public override void PobierzInformacje()
        {
            Console.WriteLine($"ID: {ID}, Tytuł: {Tytuł}, Reżyser: {Reżyser}, Rok produkcji: {RokProdukcji}, Gatunek: {Gatunek}, Czas trwania: {CzasTrwania} min, Ocena: {Ocena}, Dostępny: {Dostępny}");
        }

        public bool Equals(Film? other)
        {
            if (other == null) { return false; }
            return Tytuł.Equals(other.Tytuł);
        }

        public override string ToString()
        {
            return $"ID: {ID}, Tytuł: {Tytuł}, Reżyser: {Reżyser}, Rok produkcji: {RokProdukcji}, Gatunek: {Gatunek}, Czas trwania: {CzasTrwania} min, Ocena: {Ocena}, Dostępny: {Dostępny}";
        }

    }
}
