﻿using Projekt_filmy;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace GUI_Projekt
{
    /// <summary>
    /// Logika interakcji dla klasy DodajFilmWindow.xaml
    /// </summary>
    public partial class DodajFilmWindow : Window
    {
        Film nowyFilm;
        public bool DodanoFilm { get; private set; }

        public DodajFilmWindow()
        {
            InitializeComponent();
            nowyFilm = new Film();
            Closed += DodajFilmWindow_Closed;
        }

        private void BtnDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            bool res = false;

            if (clickedButton != null)
            {
                // Pobierz dane z TextBox-ów
                string tytul = TxtTytul.Text;
                string rezyser = TxtRezyser.Text;
                int rokProdukcji = int.Parse(TxtRokProdukcji.Text);
                string gatunek = TxtGatunek.Text;
                int czasTrwania = int.Parse(TxtCzasTrwania.Text);
                double ocena = double.Parse(TxtOcena.Text);
                bool dostepny = ChkDostepny.IsChecked ?? false;

                // Ustaw dane w obiekcie nowego filmu
                nowyFilm.Tytuł = tytul;
                nowyFilm.Reżyser = rezyser;
                nowyFilm.RokProdukcji = rokProdukcji;
                nowyFilm.Gatunek = gatunek;
                nowyFilm.CzasTrwania = czasTrwania;
                nowyFilm.Ocena = ocena;
                nowyFilm.Dostępny = dostepny;

                // Dodaj film do bazy danych
                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\nowePO\\Projekt_filmy\\GUI_Projekt\\bazafilmow1.xml";
                BazaDanych bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);
                bazaDanych.DodajFilm(nowyFilm);
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                DodanoFilm = true; // Ustawienie DodanoFilm na true po dodaniu filmu

                DialogResult = true;
            }
            else
            {
                DialogResult = false;
            }
;
        }

        private void Button_Click_anuluj(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        public void DodajFilmWindow_Closed(object sender, EventArgs e)
        {
            // Po zamknięciu okna odśwież MainWindow
            if (DodanoFilm)
            {
                MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
                if (mainWindow != null)
                {
                    mainWindow.RefreshPage();
                }
            }
        }
    }
}
