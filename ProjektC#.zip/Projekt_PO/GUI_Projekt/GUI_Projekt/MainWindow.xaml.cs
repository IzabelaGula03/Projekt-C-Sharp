﻿using Projekt_filmy;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI_Projekt
{
    public partial class MainWindow : Window
    {
        private BazaDanych bazaDanych;


        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;

            // Wczytaj bazę danych z pliku XML
            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
            this.bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);
        }


        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Wczytaj bazę danych z pliku XML
            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
            this.bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);

            // Ustaw źródło danych dla ListBox z filmami
            LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);

            // Ustaw źródło danych dla ListBox
            LstKlienci.ItemsSource = bazaDanych.Klienci;

            // Ustaw niestandardowy szablon wyświetlania elementów
            LstKlienci.ItemTemplate = new DataTemplate(typeof(Klient));

            FrameworkElementFactory stackPanelFactory = new FrameworkElementFactory(typeof(StackPanel));
            stackPanelFactory.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

            FrameworkElementFactory klientTextFactory = new FrameworkElementFactory(typeof(TextBlock));
            klientTextFactory.SetBinding(TextBlock.TextProperty, new Binding());

            stackPanelFactory.AppendChild(klientTextFactory);

            LstKlienci.ItemTemplate.VisualTree = stackPanelFactory;

            // Wczytaj bazę danych z pliku XML (to wydaje się być powtórzeniem, sprawdź czy jest to zamierzone)
            bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);

            // Ustaw źródło danych dla ListBox z filmami
            LstFilmy.ItemsSource = bazaDanych.Filmy;

            // Ustaw niestandardowy szablon wyświetlania elementów
            LstFilmy.ItemTemplate = new DataTemplate(typeof(Film));

            FrameworkElementFactory filmTextFactory = new FrameworkElementFactory(typeof(TextBlock));
            filmTextFactory.SetBinding(TextBlock.TextProperty, new Binding());

            LstFilmy.ItemTemplate.VisualTree = filmTextFactory;
        }


        private void BtnDodajKlient_Click(object sender, RoutedEventArgs e)
        {
            Klient k = new Klient();
            DodajKlientaWindow noweOkno = new DodajKlientaWindow();
            noweOkno.ShowDialog();

            if (noweOkno.DodanoKlienta && bazaDanych is not null)
            {
                bazaDanych.DodajKlienta(k);
            }
        }


        private void BtnUsunKlienta_Click(object sender, RoutedEventArgs e)
        {
            // Sprawdź, czy został wybrany jakiś klient
            if (LstKlienci.SelectedItem != null && bazaDanych != null)
            {
                // Pobierz wybranego klienta
                Klient wybranyKlient = (Klient)LstKlienci.SelectedItem;

                // Usuń klienta z bazy danych
                bazaDanych.UsuńKlienta(wybranyKlient.ID);

                // Zapisz zmiany do pliku XML
                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                // Odśwież ListBox, aby uwzględnić usuniętego klienta
                LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);

                // Wyświetl komunikat
                MessageBox.Show($"Klient {wybranyKlient.Imię} {wybranyKlient.Nazwisko} został pomyślnie usunięty.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);


            }
        }

        public void RefreshPage()
        {
            // Odśwież główne okno
            LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);
            LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);
        }

        /*private void BtnDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            DodajFilmWindow noweOkno = new DodajFilmWindow();
            noweOkno.ShowDialog();

            if (noweOkno.DodanoFilm && bazaDanych is not null)
            {
                // Odśwież listę filmów po dodaniu nowego filmu
                LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);
            }

            RefreshPage();
        }*/

        private void BtnDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            DodajFilmWindow noweOkno = new DodajFilmWindow();
            noweOkno.ShowDialog();

            if (noweOkno.DodanoFilm && bazaDanych is not null)
            {
                // Odśwież listę filmów po dodaniu nowego filmu
                LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);
            }
        }


        private void BtnUsunFilm_Click(object sender, RoutedEventArgs e)
        {
            // Sprawdź, czy został wybrany jakiś film
            if (LstFilmy.SelectedItem != null && bazaDanych != null)
            {
                // Pobierz wybrany film
                Film wybranyFilm = (Film)LstFilmy.SelectedItem;

                // Usuń film z bazy danych
                bazaDanych.UsuńFilm(wybranyFilm.ID);

                // Zapisz zmiany do pliku XML
                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                // Odśwież ListBox, aby uwzględnić usunięty film
                LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);

                // Wyświetl komunikat
                MessageBox.Show($"Film {wybranyFilm.Tytuł} został pomyślnie usunięty.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);

                
            }
        }


        private void MenuOtworz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.InitialDirectory = Environment.CurrentDirectory;
            dlg.Filter = "xml files (*.zml)|*.xml"; ;
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                bazaDanych = BazaDanych.OdczytajZPliku(filename);
                if (bazaDanych is not null)
                {
                    LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);
                }
            }
        }
        private void MenuZapisz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                bazaDanych.ZapiszDoPliku(filename);
            }
        }
        private void MenuZakoncz_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void LstKlienci_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

            // Ustaw źródło danych dla ListBox
            LstKlienci.ItemsSource = bazaDanych.Klienci;

            // Pobierz zaznaczonego klienta
            Klient wybranyKlient = LstKlienci.SelectedItem as Klient;

        }

        private void LstFilmy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Sprawdź, czy został wybrany jakiś film
            if (LstFilmy.SelectedItem != null)
            {
                // Pobierz wybrany film
                Film wybranyFilm = (Film)LstFilmy.SelectedItem;
            }
        }

        private void BtnDodajTransakcje_Click(object sender, RoutedEventArgs e)
        {
            // Tworzenie nowego obiektu transakcji (zakładam, że masz funkcję do utworzenia nowej transakcji)
            Transakcja nowaTransakcja = UtworzNowaTransakcje();

            // Sprawdź, czy masz dostęp do bazy danych
            if (bazaDanych is not null)
            {
                // Tworzenie nowego obiektu okna TransakcjaWindow z przekazaniem danych transakcji i bazy danych
                TransakcjaWindow transakcjaWindow = new TransakcjaWindow(nowaTransakcja, bazaDanych);

                // Pokazywanie nowego okna (modalne)
                transakcjaWindow.ShowDialog();
            }
            else
            {
                // Obsługa przypadku braku bazy danych
                MessageBox.Show("Błąd: Brak dostępu do bazy danych.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private Transakcja UtworzNowaTransakcje()
        {
            // Tutaj możesz zaimplementować logikę do utworzenia nowej transakcji
            // Na potrzeby przykładu, tworzymy pustą transakcję
            Transakcja nowaTransakcja = new Transakcja();

            return nowaTransakcja;
        }

    }
}
