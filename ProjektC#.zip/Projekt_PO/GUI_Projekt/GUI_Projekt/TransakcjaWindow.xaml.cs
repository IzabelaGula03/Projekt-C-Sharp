﻿using Projekt_filmy;
using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace GUI_Projekt
{
    public partial class TransakcjaWindow : Window
    {
        private Transakcja edytowanaTransakcja;
        private BazaDanych bazaDanych;

        public TransakcjaWindow(Transakcja edytowanaTransakcja, BazaDanych bazaDanych)
        {
            InitializeComponent();
            this.edytowanaTransakcja = edytowanaTransakcja;
            this.bazaDanych = bazaDanych;
            Loaded += TransakcjaWindow_Loaded;

            // Ustaw dane na kontrolkach w oknie
            UstawDaneNaKontrolkach();

        }


        private void UstawDaneNaKontrolkach()
        {
            // Tutaj ustaw wartości na kontrolkach w oknie na podstawie edytowanej transakcji
            // Na przykład:
            TxtBoxIDTransakcji.Text = edytowanaTransakcja.IDTransakcji.ToString();
            TxtBoxIDFilmu.Text = edytowanaTransakcja.IDFilmu.ToString();
            TxtBoxIDKlienta.Text = edytowanaTransakcja.IDKlienta.ToString();
            DatePickerDataWypozyczenia.SelectedDate = edytowanaTransakcja.DataWypożyczenia;
            DatePickerDataZwrotu.SelectedDate = edytowanaTransakcja.DataZwrotu;
        }

        private void TransakcjaWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Tutaj możesz dodać dodatkowe operacje, które mają być wykonane po załadowaniu okna
            // Na przykład, wczytanie dodatkowych danych, itp.

            LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);
            LstTransakcja.DisplayMemberPath = "IDTransakcji";

            // Sprawdź i ustaw datę początkową, jeśli jest równa DateTime.MinValue
            if (DatePickerDataWypozyczenia.SelectedDate == DateTime.MinValue)
            {
                DatePickerDataWypozyczenia.SelectedDate = DateTime.Now;
            }

            // Sprawdź i ustaw datę początkową, jeśli jest równa DateTime.MinValue
            if (DatePickerDataZwrotu.SelectedDate == DateTime.MinValue)
            {
                DatePickerDataZwrotu.SelectedDate = DateTime.Now;
            }

            // ...
            LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);
            LstTransakcja.DisplayMemberPath = "IDTransakcji";

            // Dodaj obsługę zdarzenia ListTransakcja_SelectionChanged
            LstTransakcja.SelectionChanged += ListTransakcja_SelectionChanged;
        }


        // Obsługa kliknięcia przycisku Zatwierdź transakcję
        private void BtnZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            // Aktualizacja danych transakcji na podstawie wprowadzonych danych w oknie
            AktualizujDaneTransakcji();

            // Zatwierdzenie zmian (możesz to dostosować do swoich potrzeb)
            MessageBox.Show("Transakcja została zaktualizowana.");

            // Zamknięcie okna po zatwierdzeniu transakcji
            Close();
        }

        // Funkcja do aktualizacji danych transakcji na podstawie wprowadzonych danych w oknie
        private void AktualizujDaneTransakcji()
        {
            // Aktualizacja danych transakcji na podstawie wprowadzonych danych w kontrolkach
            edytowanaTransakcja.IDTransakcji = Convert.ToInt32(TxtBoxIDTransakcji.Text);
            edytowanaTransakcja.IDFilmu = Convert.ToInt32(TxtBoxIDFilmu.Text);
            edytowanaTransakcja.IDKlienta = Convert.ToInt32(TxtBoxIDKlienta.Text);
            edytowanaTransakcja.DataWypożyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            edytowanaTransakcja.DataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;
        }

        // Obsługa przycisku Anuluj transakcję
        private void BtnAnulujTransakcje_Click(object sender, RoutedEventArgs e)
        {
            // Sprawdź, czy została wybrana transakcja
            if (LstTransakcja.SelectedItem != null)
            {
                // Pobierz wybraną transakcję
                Transakcja wybranaTransakcja = (Transakcja)LstTransakcja.SelectedItem;

                // Usuń transakcję z bazy danych
                bazaDanych.Transakcje.Remove(wybranaTransakcja);

                // Zapisz zmiany do pliku XML (jeśli to potrzebne)
                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                // Odśwież ListBox, aby uwzględnić usuniętą transakcję
                LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);

                // Wyświetl komunikat
                MessageBox.Show($"Transakcja o ID {wybranaTransakcja.IDTransakcji} została pomyślnie usunięta.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            // Zamknięcie okna po anulowaniu
            Close();
        }


        private void ListTransakcja_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Sprawdź, czy jest wybrana transakcja
            if (LstTransakcja.SelectedItem != null)
            {
                // Pobierz wybraną transakcję
                Transakcja wybranaTransakcja = (Transakcja)LstTransakcja.SelectedItem;
            }
        }



        private void BtnZatwierdz1_Click(object sender, RoutedEventArgs e)
        {
            // Pobierz dane z kontrolek wprowadzania
            int idTransakcji = int.Parse(TxtBoxIDTransakcji.Text);
            int idFilmu = int.Parse(TxtBoxIDFilmu.Text);
            int idKlienta = int.Parse(TxtBoxIDKlienta.Text);
            DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

            // Utwórz nową transakcję
            Transakcja nowaTransakcja = new Transakcja
            {
                IDTransakcji = idTransakcji,
                IDFilmu = idFilmu,
                IDKlienta = idKlienta,
                DataWypożyczenia = dataWypozyczenia,
                DataZwrotu = dataZwrotu
            };

            // Dodaj nową transakcję do bazy danych
            bazaDanych.DodajTransakcję(nowaTransakcja);

            // Zapisz zmiany do pliku XML
            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
            bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

            // Odśwież ListBox, aby uwzględnić dodaną transakcję
            LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);

            // Wyświetl komunikat
            MessageBox.Show($"Transakcja o ID {idTransakcji} została pomyślnie zatwierdzona.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);

            // Zamknięcie okna po zatwierdzeniu
            Close();
        }

        private void BtnObliczOpłate_Click(object sender, RoutedEventArgs e)
        {
            // Pobierz daty z DatePicker
            DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

            // Sprawdź, czy daty są poprawne
            if (dataWypozyczenia == DateTime.MinValue || dataZwrotu == DateTime.MinValue)
            {
                MessageBox.Show("Wprowadź daty wypożyczenia i zwrotu.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Oblicz opłatę za pomocą funkcji ObliczOpłatę
            double oplata = ObliczOpłatę(dataWypozyczenia, dataZwrotu);

            // Wyświetl opłatę w TextBox
            TxtBoxOplata.Text = oplata.ToString("C"); // "C" formatuje liczbę jako walutę
        }


        private void TxtBoxOplata_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            // Pobierz dane z kontrolek wprowadzania
            DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

            // Sprawdź, czy daty są poprawne
            if (dataWypozyczenia == DateTime.MinValue || dataZwrotu == DateTime.MinValue)
            {
                MessageBox.Show("Wprowadź daty wypożyczenia i zwrotu.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Oblicz opłatę
            double oplata = ObliczOpłatę(dataWypozyczenia, dataZwrotu);

            // Wyświetl opłatę w TextBox
            TxtBoxOplata.Text = oplata.ToString("C"); // "C" formatuje liczbę jako walutę
        }

        // Funkcja do obliczania opłaty na podstawie dat wypożyczenia i zwrotu
        private double ObliczOpłatę(DateTime dataWypozyczenia, DateTime dataZwrotu)
        {
            // Zakładamy, że opłata wynosi 5.0 za dzień wypożyczenia filmu
            const double CenaZaDzien = 5.0;

            // Obliczamy różnicę w dniach między datą wypożyczenia a datą zwrotu
            TimeSpan roznicaCzasu = dataZwrotu - dataWypozyczenia;
            int dniWypozyczenia = roznicaCzasu.Days;

            // Obliczamy opłatę
            double oplata = dniWypozyczenia * CenaZaDzien;

            return oplata;
        }




    }
}
