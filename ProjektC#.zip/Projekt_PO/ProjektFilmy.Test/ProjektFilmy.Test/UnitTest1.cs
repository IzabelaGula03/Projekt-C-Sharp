// Dodaj odpowiednie usingi
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt_filmy;

namespace ProjektFilmy.Test
{
    [TestClass]
    public class BazaDanychTests
    {
        [TestMethod]
        public void DodajFilm_DodajeFilmDoListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Film film = new Film() { ID = 1, Tytu� = "Film testowy" };

            // Act
            bazaDanych.DodajFilm(film);

            // Assert
            Assert.IsTrue(bazaDanych.Filmy.Contains(film));
        }

        [TestMethod]
        public void UsunFilm_UsuwaFilmZListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Film film = new Film() { ID = 1, Tytu� = "Film testowy" };
            bazaDanych.DodajFilm(film);

            // Act
            bazaDanych.Usu�Film(1);

            // Assert
            Assert.IsFalse(bazaDanych.Filmy.Contains(film));
        }

        [TestMethod]
        public void DodajKlienta_DodajeKlientaDoListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Klient klient = new Klient() { ID = 1, Imi� = "Jan", Nazwisko = "Kowalski" };

            // Act
            bazaDanych.DodajKlienta(klient);

            // Assert
            Assert.IsTrue(bazaDanych.Klienci.Contains(klient));
        }

        [TestMethod]
        public void UsunKlienta_UsuwaKlientaZListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Klient klient = new Klient() { ID = 1, Imi� = "Jan", Nazwisko = "Kowalski" };
            bazaDanych.DodajKlienta(klient);

            // Act
            bazaDanych.Usu�Klienta(1);

            // Assert
            Assert.IsFalse(bazaDanych.Klienci.Contains(klient));
        }
        [TestMethod]
        public void DodajTransakcje_DodajeTransakcjeDoListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Transakcja transakcja = new Transakcja()
            {
                IDTransakcji = 1,
                IDFilmu = 1,
                DataZwrotu = new DateTime(2002, 12, 12),
                IDKlienta = 1,
                DataWypo�yczenia = new DateTime(2002, 12, 15)
            };

            // Act
            bazaDanych.DodajTransakcj�(transakcja);

            // Assert
            Assert.IsTrue(bazaDanych.Transakcje.Contains(transakcja));
        }


        [TestMethod]
        public void UsunTransakcje_UsuwaTransakcjeZListy()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            Transakcja transakcja = new Transakcja()
            {
                IDTransakcji = 1,
                IDFilmu = 1,
                DataZwrotu = new DateTime(2002, 12, 12),
                IDKlienta = 1,
                DataWypo�yczenia = new DateTime(2002, 12, 15)
            };

            // Act
            bazaDanych.Usu�Transakcj�(1);

            // Assert
            Assert.IsFalse(bazaDanych.Transakcje.Contains(transakcja));
        }

        [TestMethod]
        public void ZapiszDoPliku_ZapisujeDoPliku()
        {
            // Arrange
            BazaDanych bazaDanych = new BazaDanych();
            bazaDanych.DodajFilm(new Film() { ID = 1, Tytu� = "Film testowy" });

            // Act
            bazaDanych.ZapiszDoPliku("test.xml");

            // Assert
            Assert.IsTrue(File.Exists("test.xml"));
        }

        [TestMethod]
        public void OdczytajZPliku_OdczytujeZPliku()
        {
            // Arrange
            string nazwaPliku = "test.xml";
            BazaDanych oczekiwanaBaza = new BazaDanych();
            Film filmTestowy = new Film() { ID = 1, Tytu� = "Film testowy", RokProdukcji = 2000 };
            oczekiwanaBaza.DodajFilm(filmTestowy);
            oczekiwanaBaza.ZapiszDoPliku(nazwaPliku);

            // Act
            BazaDanych nowaBaza = BazaDanych.OdczytajZPliku(nazwaPliku);

            // Assert
            Assert.IsNotNull(nowaBaza);
            Assert.AreEqual(1, nowaBaza.Filmy.Count);

            // Dodatkowe asercje
            Film odczytanyFilm = nowaBaza.Filmy.FirstOrDefault();
            Assert.IsNotNull(odczytanyFilm);
            Assert.AreEqual(filmTestowy.ID, odczytanyFilm.ID);
            Assert.AreEqual(filmTestowy.Tytu�, odczytanyFilm.Tytu�);

            // Sprawd�, czy plik "test.xml" zosta� usuni�ty po zako�czeniu testu
            File.Delete(nazwaPliku);
            Assert.IsFalse(File.Exists(nazwaPliku));
        }
    }
}
