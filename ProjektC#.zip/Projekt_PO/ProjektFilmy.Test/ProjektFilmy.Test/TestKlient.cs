﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt_filmy;

namespace ProjektFilmy.Test
{
    [TestClass]
    public class KlientTests
    {
        [TestMethod]
        public void WypozyczFilm_WypozyczaFilm()
        {
            // Arrange
            Klient klient = new Klient() { ID = 1, Imię = "Jan", Nazwisko = "Kowalski" };

            // Act
            klient.WypożyczFilm();

        }

        [TestMethod]
        public void ZwróćFilm_ZwracaFilm()
        {
            // Arrange
            Klient klient = new Klient() { ID = 1, Imię = "Anna", Nazwisko = "Nowak" };

            // Act
            klient.ZwróćFilm();

        }

        [TestMethod]
        public void SprawdzHistorieWypozyczen_SprawdzaHistorie()
        {
            // Arrange
            Klient klient = new Klient() { ID = 1, Imię = "Jan", Nazwisko = "Kowalski" };

            // Act
            klient.SprawdźHistorięWypożyczeń();

        }

        [TestMethod]
        public void CompareTo_PorownujeKlientow_PoprawniePorownuje()
        {
            // Arrange
            Klient klient1 = new Klient() { ID = 1, Imię = "Anna", Nazwisko = "Nowak" };
            Klient klient2 = new Klient() { ID = 2, Imię = "Jan", Nazwisko = "Kowalski" };

            // Act
            int result = klient1.CompareTo(klient2);

            // Assert
            Assert.IsTrue(result > 0);
        }

        [TestMethod]
        public void CompareTo_PorownujeKlientow_ObajTeSame()
        {
            // Arrange
            Klient klient1 = new Klient() { ID = 1, Imię = "Jan", Nazwisko = "Kowalski" };
            Klient klient2 = new Klient() { ID = 2, Imię = "Jan", Nazwisko = "Kowalski" };

            // Act
            int result = klient1.CompareTo(klient2);

            // Assert
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void CompareTo_PorownujeKlientow_Klient2PrzedKlient1()
        {
            // Arrange
            Klient klient1 = new Klient() { ID = 1, Imię = "Jan", Nazwisko = "Kowalski" };
            Klient klient2 = new Klient() { ID = 2, Imię = "Adam", Nazwisko = "Nowak" };

            // Act
            int result = klient1.CompareTo(klient2);

            // Assert
            Assert.IsTrue(result < 0);
        }

        [TestMethod]
        [ExpectedException(typeof(WrongFilmException))]
        public void SetEmail_NieprawidlowyEmail_RzucaWyjatek()
        {
            // Arrange
            Klient klient = new Klient();

            // Act
            klient.Email = "nieprawidlowy_email";
        }

        [TestMethod]
        [ExpectedException(typeof(WrongFilmException))]
        public void SetNumerTelefonu_NieprawidlowyNumer_RzucaWyjatek()
        {
            // Arrange
            Klient klient = new Klient();

            // Act
            klient.NumerTelefonu = "123"; // Numer telefonu krótszy niż 9 cyfr

        }
    }
}
