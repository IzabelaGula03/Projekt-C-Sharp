﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt_filmy;

namespace ProjektFilmy.Test
{
    [TestClass]
    public class FilmTests
    {
        [TestMethod]
        public void Wypozycz_WypozyczaFilm()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy", Dostępny = true };

            // Act
            film.Wypożycz();

            // Assert
            Assert.IsFalse(film.Dostępny);
        }


        [TestMethod]
        public void Zwroc_ZwracaFilm()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy", Dostępny = false };

            // Act
            film.Zwróć();

            // Assert
            Assert.IsTrue(film.Dostępny);
        }

        [TestMethod]
        public void SprawdzDostepnosc_FilmDostepny_ZwracaTrue()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy", Dostępny = true };

            // Act
            bool dostepnosc = film.SprawdźDostępność();

            // Assert
            Assert.IsTrue(dostepnosc);
        }

        [TestMethod]
        public void SprawdzDostepnosc_FilmNiedostepny_ZwracaFalse()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy", Dostępny = false };

            // Act
            bool dostepnosc = film.SprawdźDostępność();

            // Assert
            Assert.IsFalse(dostepnosc);
        }

        [TestMethod]
        public void RokProdukcji_PoprawnyRok_UstawiaRokProdukcji()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy" };

            // Act
            film.RokProdukcji = 2000;

            // Assert
            Assert.AreEqual(2000, film.RokProdukcji);
        }

        [TestMethod]
        [ExpectedException(typeof(WrongFilmException))]
        public void RokProdukcji_NieprawidlowyRok_RzucaWyjatek()
        {
            // Arrange
            Film film = new Film() { ID = 1, Tytuł = "Film testowy" };

            // Act
            film.RokProdukcji = 1800; // Rok spoza dozwolonego zakresu
        }
    }
}
