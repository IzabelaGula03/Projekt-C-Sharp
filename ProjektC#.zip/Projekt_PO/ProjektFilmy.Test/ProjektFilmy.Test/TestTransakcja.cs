﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt_filmy;
using System;

namespace ProjektFilmy.Test
{
    [TestClass]
    public class TransakcjaTests
    {
        [TestMethod]
        public void ObliczOplate_CalkowitaOplataJestPoprawna()
        {
            // Arrange
            Transakcja transakcja = new Transakcja()
            {
                IDTransakcji = 1,
                IDFilmu = 1,
                IDKlienta = 1,
                DataWypożyczenia = new DateTime(2022, 1, 1),
                DataZwrotu = new DateTime(2022, 1, 5)
            };

            // Act
            double oplata = transakcja.ObliczOpłatę();

            // Assert
            Assert.AreEqual(20.0, oplata); // 4 dni * 5.0 zł za dzień
        }

        [TestClass]
        public class TransakcjaTests1
        {
            [TestMethod]
            public void PobierzInformacje_PoprawnieWyswietlaInformacje()
            {
                // Przygotowanie danych testowych
                Transakcja transakcja = new Transakcja()
                {
                    IDTransakcji = 1,
                    IDFilmu = 1,
                    IDKlienta = 1,
                    DataWypożyczenia = new DateTime(2022, 1, 1),
                    DataZwrotu = new DateTime(2022, 1, 10)
                };

                // Określenie oczekiwanego wyjścia
                string expectedOutput = $"IDTransakcji: 1, IDFilmu: 1, IDKlienta: 1, Data wypożyczenia: 01.01.2022 00:00:00, Data zwrotu: 10.01.2022 00:00:00";

                // Przechwycenie standardowego wyjścia
                StringWriter sw = new StringWriter();
                Console.SetOut(sw);

                // Wywołanie metody PobierzInformacje
                transakcja.PobierzInformacje();

                // Przywrócenie standardowego wyjścia
                Console.SetOut(Console.Out);

                // Odczytanie zapisanego wyjścia
                string actualOutput = sw.ToString().Trim(); // Dodano Trim(), aby pozbyć się ewentualnych białych znaków na końcu.

                // Asercja
                Assert.AreEqual(expectedOutput, actualOutput, "Komunikat błędu, jeśli dane nie są zgodne z oczekiwaniami");
            }
        }
    }
}
